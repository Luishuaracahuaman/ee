
package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author USUARIO
 */
public class test {
        public static void main(String[] args) throws ClassNotFoundException {

        String jdbcUrl = "jdbc:mysql://datos-1.ct23s4yun1v5.us-east-1.rds.amazonaws.com:3306/Record?characterEncoding=UTF-8";
        String username = "luis";
        String password = "enrique12345..";

        Connection connection = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            //conexion
            connection = DriverManager.getConnection(jdbcUrl, username, password);

            if (connection != null) {
                System.out.println("Conexion exitosa");
            }

        } catch (SQLException e) {
            System.out.println("error conexion base de datos: " + e);
        }

    }
}
