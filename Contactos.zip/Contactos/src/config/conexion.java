package config;

import java.sql.Connection;
import java.sql.DriverManager;

public class conexion {

    Connection con;

    public conexion() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://datos-1.ct23s4yun1v5.us-east-1.rds.amazonaws.com:3306/Record?characterEncoding=UTF-8", "luis", "enrique12345..");
        } catch (Exception e) {
            System.out.println("Error clase conexion: " + e);
        }
    }

    public Connection getConnection(){
        return con;
    }
    
    public void getdemo(){
    }
}
